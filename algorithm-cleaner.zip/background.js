// 확장 프로그램이 받는 메시지를 감지하고 처리하는 코드
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

    // 메시지 안에 있는 action 값이 "startCleaning"일 때만 실행
    if (message.action === "startCleaning") {
  
      // 저장소에서 이전에 저장해둔 keyword 값을 불러옴
      chrome.storage.local.get(["keyword"], (data) => {
  
        // 검색 키워드를 유튜브 검색 주소에 넣음
        // 예: https://www.youtube.com/results?search_query=고양이
        const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(data.keyword)}`;
  
        // 새 탭을 열어서 위 주소로 이동시킴 (즉, 유튜브에서 자동으로 검색함)
        chrome.tabs.create({ url: searchUrl });
      });
    }
  });
  