// 일정 시간(ms 밀리초 단위) 기다리는 함수
// 예: sleep(2000)은 2초 기다림
async function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  // 알고리즘 세탁 기능의 핵심 함수
  // keyword: 검색어, count: 시청할 영상 수, delay: 각 영상 시청 시간(초)
  async function startAlgorithmCleaning(keyword, count, delay) {
    // 유튜브 검색 결과 페이지에서 영상 제목 요소들을 모두 가져옴
    const videos = Array.from(document.querySelectorAll('a#video-title')).slice(0, count);
  
    // 가져온 영상 목록을 하나씩 반복
    for (let i = 0; i < videos.length; i++) {
      // 새 탭으로 해당 영상 열기
      window.open(videos[i].href, '_blank');
  
      // 설정한 시간(초 단위)만큼 기다림
      await sleep(delay * 1000);
    }
  }
  
  // 크롬 저장소에서 키워드, 영상 개수, 대기 시간 정보를 불러옴
  chrome.storage.local.get(["keyword", "count", "delay"], (data) => {
  
    // 현재 주소가 유튜브 검색 결과 페이지가 아니면 실행 안 함
    if (!location.href.includes("youtube.com/results")) return;
  
    // 웹페이지 내용이 완전히 로드되었을 때 알고리즘 세탁 시작
    window.addEventListener("load", () => {
      startAlgorithmCleaning(data.keyword, data.count, data.delay);
    });
  });
  