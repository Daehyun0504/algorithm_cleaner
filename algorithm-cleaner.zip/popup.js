// 'Start Cleaning' 버튼을 누르면 아래의 기능이 실행되도록 설정
document.getElementById('startBtn').addEventListener('click', () => {

    // 입력한 키워드를 가져옴 (예: '아이돌', '고양이 영상' 등)
    const keyword = document.getElementById('keyword').value;
  
    // 입력한 영상 개수(count)를 숫자로 바꿈 (예: 3, 5개 등)
    const count = parseInt(document.getElementById('count').value);
  
    // 입력한 지연 시간(delay, 초 단위)을 숫자로 바꿈 (예: 10초, 30초 등)
    const delay = parseInt(document.getElementById('delay').value);
  
    // 입력값이 하나라도 비었거나 잘못된 숫자이면 경고창을 띄우고 멈춤
    if (!keyword || isNaN(count) || isNaN(delay)) {
      alert("모든 필드를 정확히 입력하세요.");
      return; // 코드 실행 중단
    }
  
    // 유효한 값이 입력되었으면, 값을 저장해둠 (크롬 확장 전용 저장소에 저장)
    chrome.storage.local.set({ keyword, count, delay }, () => {
  
      // "startCleaning"이라는 메시지를 백그라운드 스크립트로 보냄
      chrome.runtime.sendMessage({ action: "startCleaning" });
  
      // 팝업 창 닫기 (설정 끝났으니 자동 종료)
      window.close();
    });
  });
  